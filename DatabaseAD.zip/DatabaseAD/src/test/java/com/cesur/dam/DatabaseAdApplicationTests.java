package com.cesur.dam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseAdApplicationTests {

	@Test
	void contextLoads() {
	}

}
