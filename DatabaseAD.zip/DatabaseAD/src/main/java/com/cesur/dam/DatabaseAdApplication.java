package com.cesur.dam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseAdApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseAdApplication.class, args);
	}

}
