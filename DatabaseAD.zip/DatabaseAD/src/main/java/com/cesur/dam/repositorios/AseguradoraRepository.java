package com.cesur.dam.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cesur.dam.Entidades.Aseguradora;

public interface AseguradoraRepository extends JpaRepository<Aseguradora, Long> {
}
